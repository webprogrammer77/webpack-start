let add = (a,b) => a+b
console.log(add(2,6))
